<!-- Sidebar -->
<ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

<!-- Sidebar - Brand -->
<a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
    <div class="sidebar-brand-icon rotate-n-15">
        
    </div>
    <div class="sidebar-brand-text mx-3">Student Organizations<sup><br>Management System</sup></div>
</a>

<!-- Divider -->
<hr class="sidebar-divider my-0">

<!-- Nav Item - Dashboard -->
<li class="nav-item active">
    <a class="nav-link" href="admin_dashboard.php">
        <i class="fas fa-fw fa-tachometer-alt"></i>
        <span>Dashboard</span></a>
</li>

<!-- Divider -->
<hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
    Organizations
</div>

<!-- Nav Item - Pages Collapse Menu -->
<li class="nav-item active">
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseTwo"
        aria-expanded="true" aria-controls="collapseTwo">
        <i class="fas fa-university fa-cog"></i>
        <span>Colleges</span>
    </a>
    <div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Choose Department:</h6>
            <a class="collapse-item" href="buttons.html">CAST</a>
            <a class="collapse-item" href="cards.html">IN</a>
        </div>
    </div>
</li>

<!-- Nav Item - Pages Collapse Menu -->
<li class="nav-item active">
    <a class="nav-link" href="admin_officers.php">
        <i class="fas fa-fw fa-users"></i>
        <span>Officers</span></a>
</li>
    <!--<div id="collapseMembers" class="collapse" aria-labelledby="headingMembers" 
    data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Choose Organization:</h6>
            <a class="collapse-item" href="buttons.html">org1</a>
            <a class="collapse-item" href="cards.html">org2</a>
        </div>
    </div>-->
</li>
<!-- Divider -->
<hr class="sidebar-divider">

<!-- Nav Item - Event Collapse Menu -->
<li class="nav-item active">
    <a class="nav-link" href="admin_event.php">
        <i class="fas fa-fw fa-calendar-alt"></i>
        <span>Events</span></a>
</li>
    
</li>

<!-- Divider -->
<hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
    Records
</div>

<!-- Nav Item - Utilities Collapse Menu -->
<li class="nav-item active">
    <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseRecords"
        aria-expanded="true" aria-controls="collapseRecords">
        <i class="fas fa-fw fa-hand-holding-usd"></i>
        <span>Financial</span>
    </a>
    <div id="collapseRecords" class="collapse" aria-labelledby="headingRecords"
        data-parent="#accordionSidebar">
        <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">Choose Record:</h6>
            <a class="collapse-item" href="records.html">Membership Fee</a>
            <a class="collapse-item" href="records.html">Expenses</a>
            <a class="collapse-item" href="records.html">...</a>
        </div>
    </div>
</li>

<!-- Divider -->
<hr class="sidebar-divider">

<!-- Heading -->
<div class="sidebar-heading">
    OTHER
</div>

<!-- Nav Item - Pages Collapse Menu -->
<li class="nav-item active">
<a class="nav-link" href="admin_users.php">
        <i class="fas fa-fw fa-users"></i>
        <span>Users</span>
    </a>

</li>


<!-- Divider -->
<hr class="sidebar-divider d-none d-md-block">

<!-- Sidebar Toggler (Sidebar) -->
<div class="text-center d-none d-md-inline">
    <button class="rounded-circle border-0" id="sidebarToggle"></button>
</div>



</ul>
<!-- End of Sidebar -->
